# exFAT for Tiger (PowerPC)

A small menu bar app + command line tools that let Mac OS X 10.4 Tiger (yes, PowerPC, yes, 2005) read and write exFAT drives.

Mac OS X 10.4 Tiger（PowerPC）で exFAT ドライブの読み書きができるようになる、GUI操作だけで完結するメニューバーアプリです。

![exFAT Menu icon](icon/icon-source-1024.png)

## Why this exists

I still use a Power Mac G4 running Tiger for daily light work, because it's just... snappy. Faster to feel usable than a lot of modern machines doing the same simple tasks. But exFAT support only came to Mac OS X in 10.6.5, and current MacFUSE / macFUSE dropped PowerPC after Leopard, so a G4 owner in 2026 has basically no way to read a modern exFAT flash drive.

Turns out the pieces to fix this already existed (old MacFUSE 1.7.0 built for 10.4, and the open-source `fuse-exfat` project), they just never got put together and tested on real Tiger PPC hardware before, as far as I could find. So I built it, with a lot of help from Claude (Anthropic's AI) doing the actual remote debugging over SSH on my G4 — I don't write Objective-C, and honestly this old toolchain has enough weird corners that even the AI needed several tries. Full transparency: yes, an AI helped write this and part of this README. I only know a little English, so please don't expect perfect wording here — Japanese and English don't even build sentences in the same order, and I'd rather ship something useful than spend a week polishing my grammar. If that bothers you, the source and the technical notes below should be enough to judge the actual work on its own.

## What's in here

- **exFAT Menu.app** — menu bar utility. Click the "exFAT" item, pick a drive to mount or a mounted one to eject, or format one as exFAT.
- **bin/** — the underlying command line tools (`mount.exfat`, `fsck.exfat`, `mkfs.exfat`, `exfatlabel`, `dumpexfat`, `exfatattrib`), built from [relan/exfat](https://github.com/relan/exfat) with two small patches for this old MacFUSE (see `patches/`).
- **src/** — the app's Objective-C source (no nib file, no Xcode project needed — it's small enough to just compile directly).

## Requirements

- Mac OS X 10.4 Tiger, PowerPC (should also work on Intel Tiger, untested)
- [MacFUSE Core 10.4-1.7.0](https://web.archive.org/web/20120127043005/http://macfuse.googlecode.com/files/MacFUSE-Core-10.4-1.7.0.dmg) installed first (this is the old Google-era MacFUSE, from the Wayback Machine — the "official" download you'll find today is a newer stub installer that just phones home to a server Google shut down years ago, and won't work)

**Leopard (10.5)?** Untested — I don't have a 10.5 machine to try it on. The app and CLI tools themselves are plain Tiger-built binaries and should run fine, but MacFUSE shipped separate kext packages per OS version back then, and this repo only ships/tests against the 10.4 one. If you try it on Leopard with a 10.5-specific MacFUSE build, it might work, but no promises — let me know how it goes either way.

## Download

Get the latest release (`exfat-tiger-ppc.zip`, app + CLI tools bundled together) here:

- https://github.com/watermark-hd/exfat-tiger-ppc/releases/latest
- On AquaFox or other old/vintage browsers, use this link instead (lighter page, same download): https://github.com/watermark-hd/exfat-tiger-ppc/releases/expanded_assets/v1.3

## Install

1. Install MacFUSE Core 10.4-1.7.0 (link above), reboot if it asks.
2. From inside this extracted folder (don't move `exFAT Menu.app` out yet), double-click it and try mounting a drive. First time, it'll ask for an admin password and install the CLI tools (`bin/`) into `/usr/local/sbin` on its own — no Terminal needed (as of v1.2). It lives in the menu bar only, no Dock icon.
3. After that first successful install, the CLI tools are on your system for good, so you can move `exFAT Menu.app` to `/Applications` or wherever you like.

*(If you skip straight to step 3 before ever launching from inside this folder, the app won't find `bin/` next to it and can't install anything — go back to step 2 first, from inside the extracted folder.)*

日本語: 1. 上記のMacFUSE Core 10.4-1.7.0をインストール（再起動を求められたら再起動）。2. この解凍したフォルダの中から（`exFAT Menu.app`をまだ移動しないで）そのままダブルクリックして起動し、ドライブのマウントを試してください。初回は管理者パスワードを求められ、CLIツール（`bin/`）が自動で`/usr/local/sbin`にインストールされます（v1.2以降、ターミナル操作不要）。3. 一度インストールが成功すれば、CLIツールはシステムに恒久的に入るので、その後は`exFAT Menu.app`を`アプリケーション`フォルダなど好きな場所に移動して構いません。（先に3を行い、このフォルダの中から一度も起動しないままアプリを移動してしまうと、`bin/`が見つからずインストールできません。その場合は解凍したフォルダの中から起動し直してください。）

## Using it

Plug in an exFAT drive. Tiger will complain it can't read it — ignore that dialog, it's Tiger's own broken built-in NTFS driver trying (and failing) to guess the filesystem, not this app.

Click "exFAT" in the menu bar → "Mount: disk_s_ (...)". A folder alias named `exFAT (disk_s_)` appears on your Desktop — that's your drive. To remove the drive, use the app's "Eject" entry first, *then* unplug (same as any other drive).

To format a drive as exFAT, pick "Format: disk_s_ (...)..." from the same menu, type a volume name (max 15 characters) and click "Erase and Format". It asks for an admin password. For safety, only external USB/FireWire drives are listed and the startup disk is always refused. Also it only formats partitions that are already Windows-type (`Windows_NTFS` / `Microsoft Basic Data`) — a FAT32 or Mac (HFS+) formatted drive is not supported yet, because the partition type would also need to be changed, and that's not done here.

フォーマット：同じメニューの「フォーマット: disk_s_ (...)...」を選び、ボリューム名（15文字まで）を入れて「消去してフォーマット」。管理者パスワードが必要です。安全のため、USB/FireWire接続の外付けドライブのみが対象で、起動ディスクは常に拒否します。また対象はすでにWindows系（`Windows_NTFS` / `Microsoft Basic Data`）のパーティションのみで、FAT32やMac (HFS+)のドライブは未対応です（パーティション種別の書き換えも必要になるため）。

## Technical notes, for anyone doing similar archaeology

A few things that weren't documented anywhere I could find, in case they save someone else a night of debugging:

- **`-o big_writes` breaks this old libfuse.** `fuse-exfat` enables it by default on any non-Linux \*BSD-flavored build, but MacFUSE 1.7.0 (2008) doesn't understand the option and mount just fails with `fuse: unknown option 'big_writes'`. Patched out.
- **`diskutil info` on every attached disk can hang the whole machine.** If any external drive is spun down, each call blocks waiting for it to wake up. Don't loop `diskutil info` over partitions — parse `diskutil list` (one call) instead.
- **exFAT drives show up as `Windows_NTFS`** at the partition-map level, so Tiger auto-mounts them with its own read-only NTFS driver on insertion. That mount is empty and useless (real NTFS ≠ exFAT internally) — the app runs `diskutil unmount` on the raw device before mounting for real, to get rid of it.
- **Finder's own "MacFUSE Volume N" desktop icon for FUSE mounts is unreliable** — sometimes it shows up, sometimes it doesn't, and either way it can survive a clean unmount as a dead, empty-looking icon that needs a full logout to clear. Passing `-o nobrowse` to the mount stops MacFUSE from registering with DiskArbitration/Finder at all — but that option is silently dropped unless you also patch fuse-exfat's option passthrough allowlist (see `patches/`). The app makes its own plain Desktop symlink instead, which turned out to be 100% reliable where Finder's native integration wasn't.
- Building this needs `autoconf`/`automake` that Tiger doesn't have — generate `./configure` on a modern Mac and copy the pre-generated tree over, or install Tigerbrew.

## Changelog

**v1.3** (2026-11-24)
- Added "Format" to the menu: erase a drive and make a fresh exFAT on it, with volume name input. External USB/FireWire drives only, startup disk is always refused. / メニューに「フォーマット」を追加（ボリューム名指定可）。USB/FireWire接続の外付けドライブのみ対象、起動ディスクは常に拒否

**v1.2** (2026-09-17)
- The app now installs the CLI tools itself (prompting for an admin password) if they're missing, instead of requiring you to run `install.sh` in Terminal first. / CLIツールが未インストールの場合、アプリ自身が管理者パスワードを求めて自動インストールするように（これまでは事前にターミナルで`install.sh`を実行する必要があった）
- The "Eject" menu item now shows free/total space for the mounted drive, since Finder's Get Info can't show Capacity for this kind of mount (see Technical notes). / 「取り出す」メニューにマウント中ドライブの空き容量/総容量を表示するように（この種のマウントはFinderの情報を見るで容量が出せないため、詳細は「技術メモ」参照）

**v1.1** (2026-09-15)
- Menu bar UI now shows English when the system language isn't Japanese (was Japanese-only before). / メニューバーのUIを英語対応（システム言語が日本語以外なら英語表示に、これまでは日本語決め打ちだった）
- Fixed drives on GPT-partitioned disks (type `Microsoft Basic Data`) not being detected at all — `diskutil list` parsing assumed the type column was always a single word. / GPTパーティション上のドライブ（`Microsoft Basic Data`など）が検出されない不具合を修正（`diskutil list`のパースがtype列を常に1単語と仮定していたため）

**v1.0** (2026-08-22)
- Initial release. / 初回リリース。

## Credits

- [relan/exfat](https://github.com/relan/exfat) — the actual exFAT filesystem implementation, GPLv2
- Google's original MacFUSE 1.7.0 for 10.4
- [daniel-toman/homebrew-exfat](https://github.com/daniel-toman/homebrew-exfat) — the README that pointed at the right pieces and got this whole idea started

## License

The CLI tools bundled here are `fuse-exfat`, GPLv2 (see `LICENSE-GPLv2.txt`). The app source and icon in this repo (`src/`, `icon/`, `install.sh`) are MIT (see `LICENSE`).

---

※マウント・取り出しのメニューは、普段のAppleメニュー（画面左側）ではなく、画面右側のバッテリーなどが表示されているメニューバーエリアに出ます。ここは絶対に迷うところなので注意してください。
